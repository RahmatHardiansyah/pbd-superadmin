<html>
<head>
	<title>Data Prodi</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("location:login.php");
}
?>
	<div class="wrap">
		
		<nav class="menu">
			<ul>
				<li>
					<a href="halaman_admin.php">Home</a>
				</li>
				<li>
					<a href="dataprodi.php">PRODI</a>
				</li>
				<li>
					<a href="datauser.php">USER</a>
				</li>

			</ul>
		</nav>
		<aside class="sidebar">
			<div class="widget">
				<h2>Keterangan Login</h2>
				<p>
    			<?php echo "Welcome " . $_SESSION['username'] . " | <a href=sistem.php?op=out>LOG Out</a>"; ?>
				</p>
			</div>
			<div class="widget">
				<h2>Sebagai</h2>
				<p><?php
   					 if ($_SESSION['jenisuser'] == '0') {
   					     $ju = 'User-Client';
 				   } else {
     					 $ju = 'User-Admin';
   					}
   					 echo $ju . '<hr>';
   					 ?></p>
					</div>
					</aside>
		<div class="blog">
			<div class="conteudo">
				<div class="post-info">
					Di Posting Oleh <b>Admin</b>
				</div>
<?php
require("koneksi.php");

$hub = open_connection();
$a = @$_GET["a"];
$id = @$_GET["id"];
$sql = @$_POST["sql"];
switch ($sql) {
	case 'create':
		# code...
	create_prodi();
		break;
	case 'update':
		# code...
	update_prodi();
		break;
	case 'delete':
		# code...
	delete_prodi();
		break;
	}
	switch ($a) {
		case 'list':
			# code...
		read_data();
			break;

		case 'input':
			# code...
		input_data();
			break;

		case 'edit':
				# code...
		edit_data($id);
			break;
			
		case 'delete':
				# code...
		delete_data($id);
			break;
		default:
			# code...
		read_data();
			break;
	}
mysqli_close($hub);
?>


<?php
function read_data()
{
	global $hub;
	$query = "select * from  user";
	$result = mysqli_query($hub, $query);?>

	<h2>Daftar Data Mahasiswa</h2>
	<table border="1" cellpadding="2" class="table1">
	
	<button><a href="datauser.php?a=input">INPUT</a></button>
	<br><br>
		<tr class="re">
			<td>ID USER</td>
			<td>USERNAME</td>
			<td>PASSWORD</td>
			<td>JENIS USER</td>
			<td>LEVEL</td>
			<td>STATUS</td>
			<td>ID PRODI</td>
		</tr>

<?php while ($row=mysqli_fetch_array($result)) {?>
	<tr>
	<td><?php echo $row['iduser'];?></td>
	<td><?php echo $row['username'];?></td>
	<td><?php echo $row['password'];?></td>
	<td><?php echo $row['jenisuser'];?></td>
	<td><?php echo $row['level'];?></td>
	<td><?php echo $row['status'];?></td>
	<td><?php echo $row['idprodi'];?></td>
	<td>
		<BUTTON><a href="datauser.php?a=edit&id=<?php echo $row['iduser'];?>">EDIT</a></BUTTON>
		<BUTTON><a href="datauser.php?a=delete&id=<?php echo $row['iduser'];?>">HAPUS</a></BUTTON>
	</td>
	</tr>

	<?php } ?>
	</table>
	<?php } ?>

<?php
function input_data() {
	$row = array(
		"npm"=> "",
		"nama"=> "",
		"idprodi"=> "-"
		); ?>

<h2>Input Data Mahasiswa</h2>
<form action="datauser.php?a=list" method="post">
<input type="hidden" name="sql" value="create">
NPM<br>
<input type="text" name="npm" maxlength="8" size="8" value="<?php echo trim($row["npm"]); ?>"/><br>
<br>
NAMA MAHASISWA<br>
<input type="text" name="nama" maxlength="50" size="50" value="<?php echo trim($row["nama"]); ?>"/><br>
<br>
ID PRODI
<br>
<input type="radio" name="idprodi" value="2"
<?php if ($row["idprodi"]=='2'){
	# code...
	echo "checked=\"checked\"";}else {echo "";} 
?> >2

<input type="radio" name="idprodi" value="3"
<?php if ($row["idprodi"]=='3') {
	# code...
	echo "checked=\"checked\"";}else {echo "";} 
?> >3

<input type="radio" name="idprodi" value="4"
<?php if ($row["idprodi"]=='4') {
	# code...
	echo "checked=\"checked\"";}else {echo "";} 
?> >4

<input type="radio" name="idprodi" value="5"
<?php if ($row["idprodi"]=='5' || $row["idprodi"]=='') {
	# code...
	echo "checked=\"checked\"";}else {echo "";} 
?> >5


<br>
<br>

<input type="submit" name="action" value="Simpan">
<button><a href="datauser.php?a=list">Batal</a></button>
</form>

<?php } ?>



<?php
function edit_data($id){
global $hub;
$query = "select * from mahasiswa where idmsh = $id";
$result = mysqli_query($hub,$query);
$row = mysqli_fetch_array($result);
?>


<h2>Edit Data Mahasiswa</h2>
<form action="datauser.php?a=list" method="post">
<input type="hidden" name="sql" value="update">
<input type="hidden" name="idmsh" value="<?php echo trim($id);?>">
NPM<BR>
<input type="text" name="npm" maxlength="6" size="6" value="<?php echo trim($row["npm"]); ?>"/><BR>
<br>
NAMA MAHASISWA<br>
<input type="text" name="nama" maxlength="70" size="70" value="<?php echo trim($row["nama"]); ?>"/><BR>
<br>
ID PRODI
<BR>
<input type="radio" name="idprodi" value="2"
<?php if ($row["idprodi"]=='2'){
	# code...
	echo "checked=\"checked\"";}else {echo "";} 
?> >2

<input type="radio" name="idprodi" value="3"
<?php if ($row["idprodi"]=='3') {
	# code...
	echo "checked=\"checked\"";}else {echo "";} 
?> >3

<input type="radio" name="idprodi" value="4"
<?php if ($row["idprodi"]=='4') {
	# code...
	echo "checked=\"checked\"";}else {echo "";} 
?> >4

<input type="radio" name="idprodi" value="5"
<?php if ($row["idprodi"]=='5' || $row["idprodi"]=='') {
	# code...
	echo "checked=\"checked\"";}else {echo "";} 
?> >5

<br>
<br>

<input type="submit" name="action" value="simpan">
<button><a href="datauser.php?a=list">Batal</a></button>
</form>

<?php } ?>

<?php
function delete_data($id){
global $hub;
$query = "select * from mahasiswa where idmsh = $id";
$result = mysqli_query($hub,$query);
$row = mysqli_fetch_array($result);
?>
<h2>Hapus Data Mahasiswa</h2>
<form action="datauser.php?a=list" method="post">
<input type="hidden" name="sql" value="delete">
<input type="hidden" name="idmsh" value="<?php echo trim($id)?>">
<table border="1" cellpadding="2" class="table1">
	<tr>
		<td>NPM</td>
		<td>NAMA MAHASISWA</td>
		<td>ID PRODI</td>
	</tr>
	<tr>
		<td><?php echo trim($row["npm"])?></td>
		<td><?php echo trim($row["nama"])?></td>
		<td><?php echo trim($row["idprodi"])?></td>
	</tr>	
</table>
	
<br>

<input type="submit" name="action" value="Delete">
<BUTTON><a href="datauser.php?a=list">Batal</a></BUTTON>

</form>

<?php } ?>





<?php
function create_prodi()
{
global $hub;
global $_POST;
$query = "insert into mahasiswa (npm,nama,idprodi) values";
$query.="('".$_POST["npm"]."','".$_POST["nama"]."','".$_POST["idprodi"]."')";

mysqli_query($hub, $query) or die(mysql_error());
}
?>


<?php
function update_prodi(){
	global $hub;
	global $_POST;
	$query = "update mahasiswa";
	$query .=" SET npm='" .$_POST["npm"]."', nama='".$_POST["nama"]."', idprodi='".$_POST["idprodi"]."'";
	$query .= " where idmsh = ".$_POST["idmsh"];

mysqli_query($hub, $query) or die(mysql_error());
}
?>

<?php
function delete_prodi(){
	global $hub;
	global $_POST;
	$query = " delete from mahasiswa";
	$query .= " where idmsh = ".$_POST["idmsh"];

mysqli_query($hub, $query) or die(mysql_error());
}
?>
					
			</div>
		
		</div>
	</div>
 
</body>
</html>


