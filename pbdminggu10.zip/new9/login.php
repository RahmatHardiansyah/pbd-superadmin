<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="stylelogin.css">
</head>
<title>User Authentication</title>
<body>
    <center><h2>Login User</h2></center>
    <div class="kotak_login">
    <center><img src="pointer.jpeg"width="200px" height="100px"></center></br>
    <form action="sistem.php" method="post">
        username: <input type="text" class="form_login" name="username">
        <br>
        password : <input type="password" class="form_login" name="password">
        <br>
        <input type="submit"  class="tombol_login"  value="Login">
    </form>
</body>

</html>