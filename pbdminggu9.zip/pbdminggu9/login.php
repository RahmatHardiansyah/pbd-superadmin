<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<title>User Authentication</title>

<body>
    <h2>Login User</h2>
    <form action="sistem.php?op=in" method="post">
        username: <input type="text" name="usr">
        <br>
        password : <input type="password" name="psw">
        <br>
        <input type="submit" value="Login">
    </form>
</body>

</html>